# Version 0.40 change and bug-fix notes

- Use QGIS minimum version 3.34 and maximum version 3.99; QGIS 4 support is not claimed.
- Select an existing line or polygon in Road mode; derive and review an approximate polygon centerline.
- Draw flat-ended buffers, retain unfinished points when switching map tools, and support Backspace/Ctrl+Z.
- Require right-click Finish and a separate confirmation before editing.
- Show line-width guidance based on DEM pixel size and offer an explicitly confirmed finer working grid.
- Add cross-section terrain sampling, terrain/grade/balanced profiles, cut and fill slope controls and a transition warning.
- Save a centerline and optional difference raster; report maximum profile grade and cut/fill.
- Keep source DEM and earlier output files; use new output names.

## Verification and limitations

Automated checks in QGIS 3.34 and 3.44 cover imports, dialog creation, flat line caps, digitizing undo and preservation, synthetic road profiles, max-grade constraints, NoData, interpolation and output files. The plugin still needs end-to-end interactive QGIS testing with representative real roads and difficult polygons before public release. The centerline is approximate and has not been proven reliable for all branches or shapes. Balanced means median-based, not globally optimal earthworks. Cut/fill transitions are approximate and must be reviewed. The algorithm retains full-raster arrays in memory.
