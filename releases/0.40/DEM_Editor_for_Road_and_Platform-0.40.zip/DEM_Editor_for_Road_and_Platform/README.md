# DEM Editor for Roads and Platforms

A QGIS 3.34–3.99 plugin for preparing preliminary terrain-following road corridors and flat platforms in a single-band DEM. Create a road by digitizing a centerline, selecting a line, or reviewing a suggested centerline from a polygon. The plugin can make a finer working grid, estimate a road profile, apply cut/fill transitions, and save new raster and vector outputs.

Read [HELP.md](HELP.md) for installation, controls, data requirements and known limitations. See [BUG_FIXES.md](BUG_FIXES.md) for changes and verification, [PLAN.md](PLAN.md) for the 0.40 scope, [CHANGELOG.md](CHANGELOG.md) for release history, and [PUBLISHING.md](PUBLISHING.md) for release checks.

Version 0.40 introduces substantial changes and is marked experimental while it receives representative interactive QGIS testing. The cut/fill and gradient calculations are preliminary approximations, not engineered road design. Do not overwrite or discard source data when testing.

Copyright (c) Vipul Chhikara. GPL version 3 or later; see LICENSE.
