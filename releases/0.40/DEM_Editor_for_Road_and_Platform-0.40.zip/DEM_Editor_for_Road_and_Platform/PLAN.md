# Version 0.40 implementation plan

Baseline: published 0.3.9 ZIP. Author: Vipul Chhikara <vipul.chhikara@gmail.com>. Supported QGIS: 3.34–3.99. Status: in progress; implementation and verification must precede any public release.

1. Add a minimisable dialog and keep drawing/review usable.
2. Support digitized lines, selected line features, and selected polygon corridors; preview and confirm automatically derived polygon centerlines; safely refuse ambiguous cases.
3. Use flat line-buffer end caps; retain and resume unfinished digitizing from its last endpoint.
4. Support Backspace/Ctrl+Z to remove the last unfinished vertex.
5. Replace automatic right-click finish with explicit Finish and Clear menu; preview and confirm Apply or cancel before all processing.
6. Show DEM pixel dimensions and advisory road widths (three and five cells), with accurate total width semantics and variable-polygon caveats.
7. Offer optional explicit finer-grid resampling, preserving original and NoData, showing estimated dimensions, with warning interpolation does not recover missing terrain.
8. Offer terrain-following, maximum-grade-constrained, and cut/fill-balanced terrain-following road profiles; never offer a fixed-elevation road.
9. Sample DEM along centerline and cross-sections across the corridor; guard curves, nodata, and ambiguous geometry.
10. Create flat cross-slope bench and automatic cut/fill daylight transitions with configurable limits and visible warnings; avoid unsupported engineering claims.
11. Save new DEM, corridor and centerline; offer difference raster, report road width/resolution, max grade, cut and fill, and verify cross-section behavior.
12. Test QGIS 3.34 and 3.44, code paths and realistic synthetic steep/curved/nodata data; document workflow, known limitations, bug fixes, publishing and compatibility.

QGIS plugin-repository metadata must include author, licence, homepage, repository and issue tracker. Increment version to 0.40; preserve package identifier from 0.3.9. Do not overwrite existing DEMs, releases or plugin data.

Verification: QGIS 3.34 and 3.44 headless dialog, DEM and output tests passed. Real 2.5 m DEM/corridor processing completed, but 10% grade test produced substantial changes and transition warnings; review visually before publication.

