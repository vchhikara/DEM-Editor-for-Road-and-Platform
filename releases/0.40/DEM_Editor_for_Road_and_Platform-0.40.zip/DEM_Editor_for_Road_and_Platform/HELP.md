# Help: DEM Editor for Roads and Platforms 0.40

## Installation

In QGIS 3.34–3.99, open Plugins > Manage and Install Plugins > Install from ZIP, choose the version 0.40 ZIP, and enable the plugin. GDAL, NumPy and SciPy must be available in QGIS Python. QGIS 4 is not claimed as supported.

## Before starting

Load a file-based, single-band DEM and set the project CRS and DEM CRS to projected coordinates in metres. Elevation values must use metres for grade and cut/fill slope settings. The plugin creates new files; preserve the original input. Check that NoData is correctly declared in your raster.

Choose a road width appropriate for the source resolution. The dialog estimates the number of DEM cells across a line-buffer road: fewer than 3 is coarse, 3–5 is rough, and 5 or more is a practical guide, not a guarantee. For Both sides, the buffer distance is measured on each side: enter 5 m for an approximately 10 m road. For Left or Right, 10 m gives approximately 10 m.

## Digitize a road

1. Open the plugin, choose Digitize a new centerline, Road mode, the DEM, buffer side and distance, and output paths.
2. Choose the profile method, smoothing, and cut/fill controls. Optionally enable a difference raster or resampling.
3. Click OK to begin drawing on the map. Click points along the road. Backspace or Ctrl+Z removes the last point.
4. If another map tool interrupts drawing, activate this plugin again to resume from the last unfinished point. Escape clears a current drawing; right-click and select Clear digitization to start over.
5. Right-click and choose Finish digitization. Inspect the displayed line and buffer; choose OK to run or Cancel to return to the unfinished line. Ends are flat for line-derived buffers.

## Use an existing line

Select exactly one continuous line feature in the line layer. Open the plugin and choose Use selected line feature. Set the buffer and editing parameters. After OK, inspect the preview and explicitly confirm to edit the DEM.

## Use a polygon

Select polygon features or use the explicit All features option. Select the polygon layer and choose Road or Flat corridor mode. In Road mode the plugin derives an approximate centerline from the polygon and shows it with the polygon before processing. Review the whole line carefully, particularly at branches, bends and islands. Cancel and choose an existing line if the proposed route is unsuitable. A polygon's existing shape is not changed.

## Road profiles and cut/fill

Terrain following uses mean terrain samples across sections and profile smoothing. Gradient controlled uses a grade-limited profile; Balanced cut and fill uses median section elevations and the same grade limit. The balanced option is an approximation, not a global cut/fill volume optimizer. Maximum grade is percent rise per horizontal distance and applies to the calculated profile before integer output rounding.

Cut slope and fill slope are vertical change divided by horizontal distance. The outside transition width is the maximum distance over which a cut/fill slope is applied. A warning is reported where the calculated transition still differs from original ground at the limit. These transitions are preliminary terrain models, and ground stability, drainage and engineering design require separate review.

## Flat platform

Choose Flat corridor mode. Enter one elevation or choose the median/mean elevation at the corridor edge. Use a digitized buffer, selected line, or polygon as the area. Choose cut and fill slopes and transition width; review the area before applying.

## Optional finer grid

Tick Create a finer interpolated working DEM and choose its pixel size in metres. The confirmation displays approximate raster dimensions and uncompressed size. The plugin saves a separate Float32 bilinear-resampled working DEM and applies the edit to it. Interpolation creates a finer grid but does not restore terrain details missing from the source. Large grids can consume substantial time, storage and memory.

## Outputs and inspection

The output includes an edited GeoTIFF, a corridor polygon shapefile and, for roads or line buffers, a centerline shapefile. If selected, a Float32 difference raster stores output minus input; positive values indicate fill and negative values indicate cut. When resampling is enabled, the difference compares against the interpolated working DEM. The success message reports changed pixels, maximum cut/fill and calculated profile grade. Existing paths get numeric suffixes.

Use QGIS Elevation Profile to check sections across the road and along its length, particularly on steep and curved sections. A 10 m road on 2.5 m pixels spans roughly four cells, so edges are necessarily coarse. Integer output DEMs round elevations. Output checks and human review remain necessary.

## Known limitations

The polygon skeleton is an approximation and may not be appropriate for branches, complex polygons, holes, multiple disconnected areas or unusually narrow corridors. The preview allows cancellation; it is not a centerline editor. Terrain following and balanced profiles do not guarantee engineering feasibility, globally optimal earthworks or exact flatness after raster sampling on bends. Small transition widths can leave a step; the plugin warns when the boundary test detects one. The DEM is loaded in memory, so large files can exceed available memory; interpolation increases that risk. Avoid selecting many overlapping or disconnected polygons for road mode.
