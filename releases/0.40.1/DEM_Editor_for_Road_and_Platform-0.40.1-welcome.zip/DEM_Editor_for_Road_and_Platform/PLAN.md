# Version 0.40.1 upgrade plan

1. Preserve centerline vertices, densify around bends and sample the corridor at adaptive stations; reduce corner rounding and improve cross-section continuity.
2. Keep the road bench separate from outside cut/fill transitions; improve edge-to-ground distances and warn at unresolved transitions.
3. Improve constrained longitudinal profile fitting using terrain samples and a maximum-grade constraint; avoid claiming globally optimized earthworks.
4. Keep existing width, profile, slope and transition controls; add inspectable road-section and cut/fill reporting.
5. Write a plain-language TXT report for every edit, with readable comparison, affected chainage and Take care cautions; optionally save the difference raster.
6. Preserve resolution advice and explicit interpolation workflow. Comparisons use matching source/output grids and disclose interpolation and volume assumptions.
7. Update help, bug-fix notes, changelog and metadata, keeping QGIS 3.34–3.99 and confirmed author information.
8. Validate straight/curved/steep roads, grade constraints, NoData, differences, report data and QGIS 3.34/3.44; assess real DEM before recommending release.

Important limits: DEM-only output is a preliminary terrain model; no geological stability can be inferred. Human review, especially at sharp bends, remains required.
