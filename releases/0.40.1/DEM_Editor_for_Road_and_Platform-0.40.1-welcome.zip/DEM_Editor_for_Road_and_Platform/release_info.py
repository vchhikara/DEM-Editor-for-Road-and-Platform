"""Welcome information for version 0.40.1."""
import os

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox, QMessageBox, QPushButton, QTextBrowser, QVBoxLayout

PLUGIN_VERSION = '0.40.1'
SETTINGS_KEY = 'DEMEditorRoadsPlatforms/last_seen_version'


def should_show():
    return QSettings().value(SETTINGS_KEY, '', type=str) != PLUGIN_VERSION


def show_guide(parent=None):
    path = os.path.join(os.path.dirname(__file__), 'HELP.md')
    try:
        with open(path, encoding='utf-8') as source:
            contents = source.read()
    except OSError as error:
        QMessageBox.warning(parent, 'User guide unavailable', str(error))
        return
    dialog = QDialog(parent)
    dialog.setWindowTitle('User guide — DEM Editor for Roads and Platforms')
    dialog.resize(720, 600)
    layout = QVBoxLayout(dialog)
    text = QTextBrowser(dialog)
    if hasattr(text, 'setMarkdown'):
        text.setMarkdown(contents)
    else:
        text.setPlainText(contents)
    layout.addWidget(text)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, parent=dialog)
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    dialog.exec()


def show_release_info(parent=None, mark_as_seen=False):
    dialog = QDialog(parent)
    dialog.setWindowTitle("What's new — DEM Editor for Roads and Platforms")
    dialog.resize(570, 430)
    layout = QVBoxLayout(dialog)
    content = QTextBrowser(dialog)
    content.setPlainText(
        'DEM Editor for Roads and Platforms — version 0.40.1\n\n'
        'WHAT IS NEW SINCE VERSION 0.3.9\n'
        '• Use a selected line or review an approximate centerline generated from a polygon.\n'
        '• Undo the last digitized vertex with Backspace or Ctrl+Z; resume an interrupted line and confirm its preview before editing.\n'
        '• Choose terrain-following, gradient-controlled or balanced cut-and-fill road profiles, with cut/fill slopes and a transition width.\n'
        '• See DEM resolution advice and optionally create a finer interpolated working DEM.\n'
        '• Bend-aware sampling and profile fitting improve road-surface calculations.\n'
        '• Review a plain-language cut/fill and DEM comparison report; optionally save a difference raster and road sampling points.\n'
        '• QGIS 3.34–3.99 is supported; QGIS 4 is not claimed as supported.\n\n'
        'HOW TO START\n'
        '1. Load a file-based DEM and use projected metre-based coordinates for the DEM and project.\n'
        '2. Choose a digitized line, a selected line, or a polygon; select Road or Flat corridor mode.\n'
        '3. Set the width, profile and transition options, and output paths. A both-sides buffer of 5 m gives an approximately 10 m wide road.\n'
        '4. For digitizing, add points, right-click and choose Finish digitization. Review the line and corridor, then confirm the edit.\n'
        '5. Inspect the output DEM and text report; use elevation profiles to check bends and steep sections.\n\n'
        'TAKE CARE\n'
        'Interpolation creates a finer grid but does not add missing terrain detail. Results are preliminary terrain models; review cross-sections, drainage and ground stability separately.\n\n'
        'Open the User Guide for full instructions and limitations.'
    )
    layout.addWidget(content)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, parent=dialog)
    guide = QPushButton('Open User Guide', dialog)
    buttons.addButton(guide, QDialogButtonBox.ButtonRole.ActionRole)
    guide.clicked.connect(lambda: show_guide(dialog))
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    dialog.exec()
    if mark_as_seen:
        QSettings().setValue(SETTINGS_KEY, PLUGIN_VERSION)
