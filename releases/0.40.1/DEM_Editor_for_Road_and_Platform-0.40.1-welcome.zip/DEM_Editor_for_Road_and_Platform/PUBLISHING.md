# QGIS publication checklist for version 0.40.1

- Confirm the source repository, homepage and tracker point to the public project and that the committed source exactly matches the ZIP.
- Confirm author Vipul Chhikara and email vipul.chhikara@gmail.com, GPL licence, icon rights and dependency availability.
- Run end-to-end GUI tests in QGIS 3.34 and a current QGIS 3 release with representative line/polygon/NoData/steep/curved/low-resolution DEMs. Verify output and failure/cancel cleanup; test Unix/macOS when available.
- Verify the QGIS 3.34–3.99 range. Do not claim QGIS 4 until tested.
- Validate metadata and the single top-level plugin folder. Exclude DEMs, test outputs, caches and archives.
- Review and upload the ZIP at https://plugins.qgis.org/ and resolve security-scan or reviewer feedback. Publishing requires a publicly accessible source repository.
- Use experimental status until the significant 0.40.1 workflow changes have completed representative user testing.

See the current requirements: https://plugins.qgis.org/docs/publish
