# Version 0.40.1 change and verification notes

- Preserve true road-line corners, connect adjacent cross-sections as triangles, and sample additional road stations near bends.
- Select cross-section intersections by distance to the station, including one-sided corridors.
- Fit grade-limited profiles to terrain with a constrained numerical solver.
- Add pre-edit sharp-bend and sampled-ground-grade cautions.
- Optionally save road cross-section sampling points for inspection.
- Save a plain-language edit report with comparison, sections and Take care cautions.
- Avoid displaying a no-change warning when only a cut/fill transition warning applies.

# Version 0.40 change and bug-fix notes

- Use QGIS minimum version 3.34 and maximum version 3.99; QGIS 4 support is not claimed.
- Select an existing line or polygon in Road mode; derive and review an approximate polygon centerline.
- Draw flat-ended buffers, retain unfinished points when switching map tools, and support Backspace/Ctrl+Z.
- Require right-click Finish and a separate confirmation before editing.
- Show line-width guidance based on DEM pixel size and offer an explicitly confirmed finer working grid.
- Add cross-section terrain sampling, terrain/grade/balanced profiles, cut and fill slope controls and a transition warning.
- Save a centerline and optional difference raster; report maximum profile grade and cut/fill.
- Keep source DEM and earlier output files; use new output names.

## Verification and limitations

Automated checks in QGIS 3.34 and 3.44 cover imports, dialog creation, flat line caps, digitizing undo and preservation, synthetic road profiles, max-grade constraints, NoData, interpolation and output files. The plugin still needs end-to-end interactive QGIS testing with representative real roads and difficult polygons before public release. The centerline is approximate and has not been proven reliable for all branches or shapes. Balanced means median-based, not globally optimal earthworks. Cut/fill transitions are approximate and must be reviewed. The algorithm retains full-raster arrays in memory.

## 0.40.1 verification and open checks

Automated numerical tests exercise straight and curved roads, preservation of a right-angle vertex, report cut/fill counts and volumes, preview cautions, sampled point output, NoData, resampling, and the grade constraint under QGIS 3.34 and 3.44. An existing 2.5 m DEM with a 200 m-wide polygon and 10% grade limit produced approximately 468 m cut and 438 m fill, with 2,431 transition-edge cells still differing from ground and 2,912 road cells using nearest-line fallback. This is a warning case, not evidence of an acceptable road. Compare representative before/after sections in interactive QGIS before any public update.

No terrain model can infer geotechnical stability from a DEM alone. The grade fit is constrained and terrain-based, but is not a global cut/fill earthworks optimizer. The preview does not calculate final cut/fill or show final cross-section charts. Polygon centerlines and close bends may still require correction.

