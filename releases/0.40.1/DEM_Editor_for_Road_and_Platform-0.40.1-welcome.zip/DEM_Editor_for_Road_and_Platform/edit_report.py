"""Plain-language, grid-aware edit report; values are preliminary estimates."""
from datetime import datetime
import os


def write_report(path, result, settings, original_dem, baseline_dem, outputs):
    d = result['report_data']
    mode = settings.get('mode', 'flat')
    profile = {'terrain':'terrain following (mean cross-section samples)',
               'grade':'gradient-controlled terrain fit',
               'balanced':'median cross-section terrain fit with grade limit'}.get(settings.get('profile_method'), 'terrain following')
    cut, fill = d['cut_pixels'], d['fill_pixels']
    lines = [
        'DEM EDIT REPORT', '=' * 60,
        'Created: ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        '', 'IN PLAIN LANGUAGE',
        'The plugin created a new DEM for a {}.'.format('terrain-following road' if mode == 'road' else 'flat platform'),
        'It lowered ground at {:,} grid cells and raised ground at {:,} grid cells.'.format(cut, fill),
        'Lowered area: {:.1f} square metres; raised area: {:.1f} square metres.'.format(d['cut_area'], d['fill_area']),
        'The deepest calculated cut is {:.2f} m; the highest fill is {:.2f} m.'.format(result['max_cut'], result['max_fill']),
        'The areas and estimated volumes below include both the corridor and its outside transition.',
        '', 'TAKE CARE',
        'This is a preliminary terrain model. Soil, rock, drainage and slope stability are not determined from a DEM.',
        'Check road cross-sections and transitions visually, especially at bends and steep ground.',
    ]
    if result.get('unmet_transition_pixels', 0):
        lines.append('The cut/fill transition still differed from the original ground at {} tested boundary cells. Increase the transition width or review the slopes.'.format(result['unmet_transition_pixels']))
    if result.get('ribbon_gap_pixels', 0):
        lines.append('{} road cells were not covered by adjacent cross-section triangles and used the nearest-line elevation instead. Review ends, bends and narrow sections.'.format(result['ribbon_gap_pixels']))
    if result.get('skipped_nodata_pixels', 0):
        lines.append('{} NoData cells in the corridor were left unchanged.'.format(result['skipped_nodata_pixels']))
    if max(result['max_cut'],result['max_fill']) > 5:
        lines.append('A cut or fill exceeds 5 m. Review the alignment, maximum grade and calculated profile; this is a review prompt, not an engineering limit.')
    if baseline_dem != original_dem:
        lines.append('The working DEM was interpolated. A finer grid does not restore missing terrain detail.')
    if settings.get('source') == 'polygon' and mode == 'road':
        lines.append('A polygon-derived centerline is approximate. Check the route at branches, bends and narrow sections.')
    if mode == 'road' and settings.get('source') != 'polygon':
        width = float(settings.get('distance', 0)) * (2 if settings.get('side') == 'both' else 1)
        cells = width / max(d['pixel_x'], d['pixel_y']) if max(d['pixel_x'], d['pixel_y']) else 0
        if cells < 5:
            lines.append('Road width spans approximately {:.1f} grid cells. Fewer than five cells can make bends and edges appear rough; interpolation does not add terrain detail.'.format(cells))
    lines += ['', 'WHAT WAS DONE', 'Input DEM: ' + original_dem,
              'Comparison baseline: ' + baseline_dem,
              'Edited DEM: ' + outputs['dem'],
              'Road/corridor source: ' + str(settings.get('source', 'unknown')),
              'Mode: ' + mode,
              'Method: ' + (profile if mode == 'road' else 'single elevation: ' + str(settings.get('flat_source','value'))),
              'Profile smoothing: {} m'.format(settings.get('smooth_m',0)),
              'Requested maximum grade: {}%'.format(settings.get('maximum_grade','not set')) if mode == 'road' and settings.get('profile_method') in ('grade','balanced') else 'Maximum grade setting: not applied',
              'Calculated maximum profile grade: {:.2f}%'.format(result['max_grade']) if result.get('max_grade') is not None else 'Profile grade: not applicable',
              'Buffer side: {}; distance per selected side: {} m'.format(settings.get('side','n/a'),settings.get('distance','n/a')) if settings.get('source') != 'polygon' else 'Road width: determined by selected polygon; width can vary.',
              'Outside transition limit: {} m; cut slope V/H: {}; fill slope V/H: {}'.format(settings.get('feather_m',0), settings.get('cut_slope',1), settings.get('fill_slope',0.5)),
              '', 'DEM COMPARISON',
              'Output grid: {:.2f} m by {:.2f} m; one cell covers {:.2f} square metres.'.format(d['pixel_x'],d['pixel_y'],d['pixel_area']),
              'Within the road/platform corridor, baseline elevations range {:.2f} to {:.2f} m; edited elevations range {:.2f} to {:.2f} m.'.format(d['source_min'],d['source_max'],d['result_min'],d['result_max']),
              'Estimated cut volume: {:.1f} cubic metres; estimated fill volume: {:.1f} cubic metres.'.format(d['cut_volume'],d['fill_volume']),
              'Volume is the sum of cell area times elevation change. It assumes horizontal and vertical units are metres and does not include compaction, shrinkage or material movement.',
              'Difference raster: ' + (outputs.get('difference') or 'not requested') + ' (positive = fill; negative = cut).',
              'The comparison uses matching cells on the output grid. The outside transition is included in whole-edit totals.',
              '', 'ROAD SECTIONS',
              'Distances are approximate metres from the start of the centerline. Sections include the road corridor and outside transition; transition cells are assigned to their nearest road cell.',
    ]
    sections=d.get('sections',[])
    if not sections: lines.append('No road sections: this was a flat-area edit or section data was unavailable.')
    else:
        for start,end,cut_max,fill_max,count in sections:
            lines.append('{:.0f}–{:.0f} m: largest cut {:.2f} m, largest fill {:.2f} m ({} corridor or transition cells).'.format(start,end,cut_max,fill_max,count))
    lines += ['', 'OUTPUT FILES']
    for label,p in outputs.items():
        if p: lines.append(label+': '+p)
    lines += ['', 'All cut/fill figures depend on the input DEM, raster resolution and chosen settings.', '']
    with open(path,'x',encoding='utf-8',newline='\n') as f: f.write('\n'.join(lines))
    return path
